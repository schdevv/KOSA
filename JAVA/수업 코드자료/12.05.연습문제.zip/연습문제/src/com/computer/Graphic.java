package com.computer;

public interface Graphic {

	// field(public static final)	
	
	// method(public abstract)
	double rendering(int size);
}
