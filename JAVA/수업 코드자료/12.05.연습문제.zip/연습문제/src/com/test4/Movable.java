package com.test4;

public interface Movable {

	void move(int x,int y);
	
}
