package test;



public class Customer {

	// 1. 생성자들.
	//    클래스안에 있는 생성자를 이용해서 class로부터
	//    instance생성할 수 있어요!
	//    결국, 모든 class는 하나 이상의 생성자를 가지고 있어요!
	//    생성자가 없는 class는 존재하지 않아요!
	//    만드는 규칙이 있어요!
	//    일단 public(public을 쓸 수 있수도 있고 아닐수도 있어요!)
	//    메소드 형태가 나와요!!!
	//    생성자는 메소드가 아니예요! => 리턴타입이 존재하지 않아요!
	//    생성자의 이름은 정해여 있어요 => 클래스의 이름으로 정해져 있어요!
	//    입력인자(parameter)를 가질 수 있어요!
	//    중괄호안에 instance의 초기화 코드가 들어와요!
	//    당연히 리턴구문은 존재하지 않아요!
	//    이렇게 만들걸 우리는 생성자(constructor)라고 합니다.!!!!!!
	public Customer() {
		// 생성될 인스턴스의 초기화코드가 들어와요!
	} 
	
	
	// 2. field들
	// 변수들이 와요! => camel case notation 
	String customerName;     // 고객이름
	public long balance;             // 잔액
	String customerAccount;  // 고객 계좌번호
	int customerAge;         // 고객 나이
	// 앗...long, int는 어디에서 봤어요. primitive data type
	// String은 primitive data type이 아니라..Reference Data type이예요!
	// 결국 String은 class라는 의미예요! 우리가 만들지 않은 class예요!
	// Java가 우리에게 제공한 class예요. 프로그램을 쉽게 하기 위해서 제공된 class예요!
	// 이런 class가 무지막지하게 많아요! (class library라고 얘기해요!)
	// 이 많은 제공된 class는 당연히 package로 묶어서 제공되요!
	// 저 위에서 String이라는 듣도보도 못한 class가 사용되었는데..당연히 이 class를
	// 사용할때 package를 명시해야해요!
	
	
	// 3. method들
	//    일반적으로 method는 특별한 용도가 아닌이상 public을 기본으로 지정해요!
	//    리턴타입 => 메소드는 우리가 알고있는 함수형태.
	//              함수는 입력을 받아서 로직처리한 후 그 결과물을 생성해서 결과물을
	//              함수를 호출한 곳으로 돌려주기 위해서 사용! => 이 돌려주는 값을 리턴값.
	//              이 리턴값이 어떤 데이터 타입인지를 method 정의할 때 선언.
	public int getAge(int kk) {
		// kk는 parameter라고 하고 method의 입력을 받아들이는 역할을 수행!~
		// business logic 처리가 진행되요!
		System.out.println("나이를 알려주는 기능이예요!");
		// if, for...
		return 30;
	}
	
}


