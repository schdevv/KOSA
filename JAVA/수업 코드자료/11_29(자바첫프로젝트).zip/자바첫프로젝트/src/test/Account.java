package test;

public class Account {

	public static void main(String args[]) {
		System.out.println("Hello!!");
		
	}
	
}
