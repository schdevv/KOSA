package sample;

interface myInterface {

	void aa();
	
}

public class InterfaceTest {

	public static void main(String[] args) {
		
		myInterface a = new myInterface() {
			
			@Override
			public void aa() {
				// TODO Auto-generated method stub
				
			}
		};
	}
}
