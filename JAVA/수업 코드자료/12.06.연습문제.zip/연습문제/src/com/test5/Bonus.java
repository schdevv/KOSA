package com.test5;

public interface Bonus {

	// field는 기본적으로 public static final이 지정
	
	// method는 기본적으로 public abstract가 지정.
	void incentive(int pay);
}
